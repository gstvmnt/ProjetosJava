package visao;

import dao.ConexaoBanco;
import controle.LivroControle;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cadastro extends JFrame {

    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    public void buscarLivro (String nome, String autor, String genero, Integer anoLancamento, Integer qtdPaginasTotal, Integer qtdPaginasLidas){
        tfNome.setText(nome);
        tfAutor.setText(autor);
        tfGenero.setText(genero);
        String anoL = String.valueOf(anoLancamento);
        tfAnoLancamento.setText(anoL);
        String qtdPT = String.valueOf(qtdPaginasTotal);
        tfQtdPaginasTotal.setText(qtdPT);
        String qtdPL = String.valueOf(qtdPaginasLidas);
        tfQtdPaginasLidas.setText(qtdPL);

    }

    public Cadastro(){
        conexao = ConexaoBanco.abreConexao();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("JavaBook Estante - Cadastro");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setContentPane(JPanel);
        tfNome.requestFocus();





        fecharButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Principal tela = new Principal();
                tela.show();
                dispose();
            }
        });




        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int anoLancamento = Integer.parseInt(tfAnoLancamento.getText());
                int qtdPaginasTotal = Integer.parseInt(tfQtdPaginasTotal.getText());
                int qtdPaginasLidas = Integer.parseInt(tfQtdPaginasLidas.getText());
                boolean sucesso;

                try{
                    LivroControle livroControle = new LivroControle();
                    sucesso = livroControle.cadastrarLivro(tfNome.getText(), tfAutor.getText(), tfGenero.getText(), Integer.parseInt(tfAnoLancamento.getText()), Integer.parseInt(tfQtdPaginasTotal.getText()), Integer.parseInt(tfQtdPaginasLidas.getText()));
                    if(sucesso == true){
                        JOptionPane.showMessageDialog(null, "Livro adiciona a Estante!");
                        limparTela();
                    }else{
                        JOptionPane.showMessageDialog(null, "Preencha as informações corretamente");
                    }

                }catch (Exception ex){
                    System.out.println(ex);
                    JOptionPane.showMessageDialog(null, "Erro : " + ex);
                }

            }
        });







        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int anoLancamento = Integer.parseInt(tfAnoLancamento.getText());
                int qtdPaginasTotal = Integer.parseInt(tfQtdPaginasTotal.getText());
                int qtdPaginasLidas = Integer.parseInt(tfQtdPaginasLidas.getText());
                boolean sucesso;

                try{
                    LivroControle livroControle = new LivroControle();
                    sucesso = livroControle.alterarLivro(tfNome.getText(), tfAutor.getText(), tfGenero.getText(), Integer.parseInt(tfAnoLancamento.getText()), Integer.parseInt(tfQtdPaginasTotal.getText()), Integer.parseInt(tfQtdPaginasLidas.getText()));
                    if(sucesso == true){
                        JOptionPane.showMessageDialog(null, "Livro editado!");
                        limparTela();
                    }else{
                        JOptionPane.showMessageDialog(null, "Preencha as informações corretamente");
                    }

                }catch (Exception ex){
                    System.out.println(ex);
                    JOptionPane.showMessageDialog(null, "Erro : " + ex);
                }


            }
        });

        excluirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean sucesso;
                LivroControle livroControle = new LivroControle();
                try {
                    sucesso = livroControle.excluirLivro(tfNome.getText());
                    if(sucesso){
                        JOptionPane.showMessageDialog(null, "Livro removido da sua estante!");
                        limparTela();
                    }else{
                        JOptionPane.showMessageDialog(null, "Erro ao remover filme");
                    }
                }catch (Exception exxx){
                    Logger.getLogger(Cadastro.class.getName()) .log(Level.SEVERE, null, exxx);
                }

            }
        });

    }

    private JPanel jpnConsulta;
    private JPanel jpnBotoes;
    private javax.swing.JPanel JPanel;
    private JButton cadastrarButton;
    private JButton fecharButton;
    private JTextField tfQtdPaginasTotal;
    private JTextField tfQtdPaginasLidas;
    private JTextField tfGenero;
    private JTextField tfAnoLancamento;
    private JButton excluirButton;
    private JTextField tfAutor;
    private JTextField tfNome;
    private JLabel lAnoLancamento;
    private JLabel lGenero;
    private JLabel lNome;
    private JLabel lAutor;
    private JLabel lQtdPaginasTotal;
    private JLabel lQtdPaginasLidas;
    private JButton pesquisarButton;
    private JButton editarButton;

    public void limparTela(){
        tfNome.setText("");
        tfAutor.setText("");
        tfGenero.setText("");
        tfAnoLancamento.setText("");
        tfQtdPaginasTotal.setText("");
        tfQtdPaginasLidas.setText("");
    }

    public static void main(String[] args) {

    }
}
