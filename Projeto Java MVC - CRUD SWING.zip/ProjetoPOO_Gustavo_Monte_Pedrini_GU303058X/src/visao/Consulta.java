package visao;

import controle.LivroControle;
import dao.ConexaoBanco;
import modelo.LivroModelo;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Consulta extends JFrame {

    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    private javax.swing.JPanel JPanel;
    private JTextField tfcNome;
    private JLabel pesquisarConsulta;
    private JTable tableConsulta;
    private JTable tbConsulta;
    private JButton sairButton;
    private JButton consultaButton;
    private JTable table1;

    public Consulta(){
            conexao = new ConexaoBanco().abreConexao();
            System.out.println(conexao);
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            setTitle("JavaBook Estante - Meus Livros");
            setVisible(true);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setResizable(false);
            setContentPane(JPanel);
            requestFocus();
            DefaultTableModel model = (DefaultTableModel) table1.getModel();
            model.addColumn("nome");
            model.addColumn("autor");
            model.addColumn("genero");
            model.addColumn("anoLancamento");
            model.addColumn("qtdPaginasTotal");
            model.addColumn("qtdPaginasLidas");
            table1.setFont(new Font("Arial", Font.BOLD, 20));
            table1.setForeground(Color.white);



            sairButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Principal tela = new Principal();
                    tela.show();
                    dispose();


                }
            });

            consultaButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String nome = tfcNome.getText();
                    DefaultTableModel tableModel = (DefaultTableModel) table1.getModel();
                    tableModel.setRowCount(0);
                    LivroControle livroControle = new LivroControle();
                    try {
                        ArrayList<LivroModelo> livros = livroControle.listarLivros(nome);
                        livros.forEach((LivroModelo livro) -> {
                            tableModel.addRow(new Object[] {livro.getNome(),
                            livro.getAutor(), livro.getGenero(), livro.getAnoLancamento(),
                            livro.getQtdPaginasTotal(), livro.getQtdPaginasLidas()});
                        });
                        table1.setModel(tableModel);

                    }catch (Exception exx){
                        Logger.getLogger(Cadastro.class.getName()).log(Level.SEVERE, null, exx);
                    }
                }
            });


            class MyMouseListener implements MouseListener {

            public void mouseClicked(MouseEvent e) {
                // Get the row that the user clicked on.
                int row = table1.rowAtPoint(e.getPoint());

                // Get the column that the user clicked on.


                // Perform any action that you want.
                String nome = (String) table1.getModel().getValueAt(table1.getSelectedRow(), 0);
                String autor = (String) table1.getModel().getValueAt(table1.getSelectedRow(), 1);
                String genero = (String) table1.getModel().getValueAt(table1.getSelectedRow(), 2);
                Integer anoLancamento = (Integer) table1.getModel().getValueAt(table1.getSelectedRow(), 3);
                Integer qtdPaginasTotal = (Integer) table1.getModel().getValueAt(table1.getSelectedRow(), 4);
                Integer qtdPaginasLidas = (Integer) table1.getModel().getValueAt(table1.getSelectedRow(), 5);
                Cadastro cadastro = new Cadastro();
                cadastro.buscarLivro(nome, autor, genero, anoLancamento, qtdPaginasTotal, qtdPaginasLidas);


                dispose();
            }

            public void mousePressed(MouseEvent e) {
            }

            public void mouseReleased(MouseEvent e) {
            }

            public void mouseEntered(MouseEvent e) {
            }

            public void mouseExited(MouseEvent e) {
            }
        }
            table1.addMouseListener(new MyMouseListener());

        }

        private void pesquisar_livro(){



        }

    public static void main(String[] args) {

    }






}

