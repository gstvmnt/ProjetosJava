package visao;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Principal extends JFrame{

    public Principal() {
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("JavaBook Estante");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setContentPane(principal);

        cadastrarLivroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cadastro tela = new Cadastro();
                tela.show();
                dispose();
            }
        });

        sobreButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Sobre tela = new Sobre();
                tela.show();
                dispose();
            }
        });

        sairButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Obrigado por usar o JavaBook! Volte Sempre");
                dispose();
            }
        });

        estanteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Consulta tela = new Consulta();
                tela.show();
                dispose();
            }
        });



    }
    private JPanel principal;
    private JButton meusLivrosButton;
    private JButton cadastrarLivroButton;
    private JLabel titleMenu;
    private JButton estanteButton;
    private JButton sairButton;
    private JButton sobreButton;
    private JInternalFrame jifInternalFrame;


    public static void main(String[] args) {

        Principal f = new Principal();







    }

}


