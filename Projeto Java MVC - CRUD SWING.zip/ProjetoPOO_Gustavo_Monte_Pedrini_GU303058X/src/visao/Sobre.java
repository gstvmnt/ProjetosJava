package visao;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Sobre extends JFrame{

    public Sobre(){
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("JavaBook Estante - Sobre");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setContentPane(panel1);
        requestFocus();

        gitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create("https://github.com/gstvmnt"));
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });

        lkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    java.awt.Desktop.getDesktop().browse(java.net.URI.create("https://www.linkedin.com/in/gustavo-monte-pedrini-252b4b21b/"));
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });
    }
    private JPanel panel1;
    private JButton lkButton;
    private JButton gitButton;



    public static void main(String[] args) {

    }
}
