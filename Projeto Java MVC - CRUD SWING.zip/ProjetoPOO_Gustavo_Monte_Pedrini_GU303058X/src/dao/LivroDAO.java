package dao;

import modelo.LivroModelo;
import java.sql.*;
import java.util.ArrayList;

public class LivroDAO {
    public void cadastrarLivro(LivroModelo livro) throws ExceptionDAO{
        String sql = "insert into javabook (nome, autor, genero, anoLancamento, qtdPaginasTotal, qtdPaginasLidas) value (?,?,?,?,?,?)";
        PreparedStatement pStatement = null;
        Connection connection = null;
        try{
            connection = ConexaoBanco.abreConexao();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, livro.getNome());
            pStatement.setString(2, livro.getAutor());
            pStatement.setString(3, livro.getGenero());
            pStatement.setInt(4, livro.getAnoLancamento());
            pStatement.setInt(5, livro.getQtdPaginasTotal());
            pStatement.setInt(6, livro.getQtdPaginasLidas());
            pStatement.execute();
        }catch (SQLException e){
            throw new ExceptionDAO("Erro ao adicionar livro na estante: " + e);
        }finally {
            try {
                if (pStatement != null) {pStatement.close();}
            } catch (SQLException e) {
                throw new ExceptionDAO("Erro ao fechar Statement: " + e);
            }try {
                if(connection != null){connection.close();}
            }catch (SQLException e){
                throw new ExceptionDAO("Erro ao fechar conexão: " + e);
            }
        }
    }

    public ArrayList<LivroModelo> listarLivros(String nome) throws ExceptionDAO{
        String sql = "select * from javabook where nome like '%" + nome + "%' order by nome";

        Connection connection = null;
        PreparedStatement pStatement = null;
        ArrayList<LivroModelo> livros = null;

        try {
            connection = ConexaoBanco.abreConexao();
            pStatement = connection.prepareStatement(sql);
            ResultSet rs = pStatement.executeQuery(sql);

            if(rs!=null){
                livros = new ArrayList<LivroModelo>();
                while (rs.next()){
                    LivroModelo livro = new LivroModelo();
                    livro.setNome(rs.getString("nome"));
                    livro.setAutor(rs.getString("autor"));
                    livro.setGenero(rs.getString("genero"));
                    livro.setAnoLancamento(rs.getInt("anoLancamento"));
                    livro.setQtdPaginasTotal(rs.getInt("qtdPaginasTotal"));
                    livro.setQtdPaginasLidas(rs.getInt("qtdPaginasLidas"));
                    livros.add(livro);
                }
            }

        }catch (SQLException e){
            throw new ExceptionDAO("Erro ao consultar sua estante! " + e);
        }finally {
            try {
                if (pStatement != null) {pStatement.close();}
            } catch (SQLException e) {
                throw new ExceptionDAO("Erro ao fechar Statement: " + e);
            }try {
                if(connection != null){connection.close();}
            }catch (SQLException e){
                throw new ExceptionDAO("Erro ao fechar conexão: " + e);
            }
        }
        return livros;
    }

    public void alterarLivro(LivroModelo livro) throws ExceptionDAO{
        String sql = "Update javabook set autor=?, genero=?, anoLancamento=?, qtdPaginasTotal=?, qtdPaginasLidas=? where nome=?";
        PreparedStatement pStatement = null;
        Connection connection = null;

        try {

            connection = ConexaoBanco.abreConexao();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, livro.getAutor());
            pStatement.setString(2, livro.getGenero());
            pStatement.setInt(3, livro.getAnoLancamento());
            pStatement.setInt(4, livro.getQtdPaginasTotal());
            pStatement.setInt(5, livro.getQtdPaginasLidas());
            pStatement.setString(6, livro.getNome());
            pStatement.execute();

        }catch (SQLException e){
            throw new ExceptionDAO("Erro ao alterar livro! " + e);
        }finally {
            try {
                if (pStatement != null) {pStatement.close();}
            } catch (SQLException e) {
                throw new ExceptionDAO("Erro ao fechar Statement: " + e);
            }try {
                if(connection != null){connection.close();}
            }catch (SQLException e){
                throw new ExceptionDAO("Erro ao fechar conexão: " + e);
            }
        }
    }

    public void excluirLivro(LivroModelo livro) throws ExceptionDAO{
        String sql = "Delete from javabook where nome=?";
        PreparedStatement pStatement = null;
        Connection connection = null;
        try{
            connection = ConexaoBanco.abreConexao();
            pStatement = connection.prepareStatement(sql);
            pStatement.setString(1, livro.getNome());
            pStatement.execute();
        }catch (SQLException e){
            throw new ExceptionDAO("Erro ao remover livro na estante: " + e);
        }finally {
            try {
                if (pStatement != null) {pStatement.close();}
            } catch (SQLException e) {
                throw new ExceptionDAO("Erro ao fechar Statement: " + e);
            }try {
                if(connection != null){connection.close();}
            }catch (SQLException e){
                throw new ExceptionDAO("Erro ao fechar conexão: " + e);
            }
        }
    }
}