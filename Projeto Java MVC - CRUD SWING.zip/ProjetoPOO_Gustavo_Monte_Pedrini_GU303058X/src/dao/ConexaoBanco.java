package dao;


import javax.swing.*;
import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;

public class ConexaoBanco {
    private static final String driverClass = "com.mysql.cj.jdbc.Driver";
    private static final String url = "jdbc:mysql://localhost:3306/javabook_poo";
    private static final String user = "root";
    private static final String password = "126943Gu-";

    public static Connection abreConexao(){
        Connection conexao = null;

        try {
            Class.forName(driverClass);
        }catch (ClassNotFoundException e){
            e.printStackTrace();
        }

        try {
            conexao = DriverManager.getConnection(url, user, password);

        }catch (SQLException e){
            //System.out.println(e);
            JOptionPane.showMessageDialog(null, "Erro ao efeturar conexão com o banco de dados: " + e);
        }
            return conexao;

    }






}
