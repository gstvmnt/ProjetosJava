package dao;

public class ExceptionDAO extends Exception {

    public ExceptionDAO(String mensagem){
        super(mensagem);
    }

}
