package modelo;

import dao.ExceptionDAO;
import dao.LivroDAO;
import java.util.ArrayList;

public class LivroModelo{
    private String nome;
    private String autor;
    private String genero;
    private int anoLancamento;
    private int qtdPaginasTotal;
    private int qtdPaginasLidas;


    public LivroModelo(){

    }
    public LivroModelo(String nome, String autor, String genero, int anoLancamento, int qtdPaginasTotal, int qtdPaginasLidas) {
        this.nome = nome;
        this.autor = autor;
        this.genero = genero;
        this.anoLancamento = anoLancamento;
        this.qtdPaginasTotal = qtdPaginasTotal;
        this.qtdPaginasLidas = qtdPaginasLidas;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public int getQtdPaginasTotal() {
        return qtdPaginasTotal;
    }

    public void setQtdPaginasTotal(int qtdPaginasTotal) {
        this.qtdPaginasTotal = qtdPaginasTotal;
    }

    public int getQtdPaginasLidas() {
        return qtdPaginasLidas;
    }

    public void setQtdPaginasLidas(int qtdPaginasLidas) {
        this.qtdPaginasLidas = qtdPaginasLidas;
    }


    public void cadastrarLivro(LivroModelo livro) throws ExceptionDAO {
        new LivroDAO().cadastrarLivro(livro);
    }

    public ArrayList<LivroModelo> listarLivros(String nome) throws ExceptionDAO{
        return new LivroDAO().listarLivros(nome);
    }

    public void alterarLivro(LivroModelo livro) throws ExceptionDAO{
        new LivroDAO().alterarLivro(livro);
    }

    public void excluirLivro(LivroModelo livro) throws ExceptionDAO{
        new LivroDAO().excluirLivro(livro);
    }
}
