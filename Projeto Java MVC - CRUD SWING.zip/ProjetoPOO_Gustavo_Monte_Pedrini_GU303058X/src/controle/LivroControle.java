package controle;


import dao.ExceptionDAO;
import modelo.LivroModelo;
import java.util.ArrayList;

public class LivroControle{

    public boolean cadastrarLivro(String nome, String autor, String genero, int anoLancamento, int qtdPaginasTotal, int qtdPaginasLidas) throws ExceptionDAO {
                if(nome != null && nome.length() > 0 || autor != null && autor.length() > 0){
                    LivroModelo livro = new LivroModelo(nome, autor, genero, anoLancamento, qtdPaginasTotal, qtdPaginasLidas);
                    livro.cadastrarLivro(livro);
                    return true;
                }
                return false;
    }

    public ArrayList<LivroModelo> listarLivros(String nome) throws ExceptionDAO{
        return new LivroModelo().listarLivros(nome);
    }

    public boolean alterarLivro(String nome, String autor, String genero, int anoLancamento, int qtdPaginasTotal, int qtdPaginasLidas) throws ExceptionDAO {
        if(nome != null && nome.length() > 0 || autor != null && autor.length() > 0){
            LivroModelo livro = new LivroModelo(nome, autor, genero, anoLancamento, qtdPaginasTotal, qtdPaginasLidas);
            livro.setNome(nome);
            livro.alterarLivro(livro);
            return true;
        }
        return false;
    }

    public boolean excluirLivro(String nome)throws ExceptionDAO{
        LivroModelo livro = new LivroModelo();
        livro.setNome(nome);
        livro.excluirLivro(livro);
        return true;
    }

}
